
public class Date 
{
	int day;
	int mon;
	int year;
	public Date()
	{
		day=0;
		mon=0;
		year=0;
	}
	public Date(int dd,int mn,int yy)
	{
		day=dd;
		mon=mn;
		year=yy;
	}
	
	public String disDate()
	{
		return day+"/"+mon+"/"+year;
	}
}
