
public class Employee 
{
	int empId;
	String empName;
	float empSal;
	char gender;
	
	public Employee()
	{
		empId=0;
		empName=null;
		empSal=0.0f;
		gender=' ';
	}
	public Employee(int empId,String empName,float empSal,char gender)
	{
		this.empId=empId;
		this.empName=empName;
		this.empSal=empSal;
		this.gender=gender;	
	}
	public String dispEmployee()
	{
		return "Employee Id :" +empId+"\nEmployee Name : "+empName+"\nEmployee Salary :"+empSal+"\nEmployee gender:"+gender+"\n";
	}
}
