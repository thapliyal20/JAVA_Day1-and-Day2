
public class TestArrayDemo
{

	public static void main(String[] args) 
	{
		int markArr[]=new int[4];
		markArr[0]=90;
		markArr[0]=10;
		markArr[0]=45;
		markArr[0]=78;
		
		for(int i=0;i<markArr.length;i++)
		{
			System.out.println("markArr["+i+"]: "+
					markArr[i]);
		}
		System.out.println("******************ALL CITIES********************");
		String []cityList={"Pune","Dehradun","Mumbai","Bangalore"};
		for(int i=0;i<cityList.length;i++)
		{
			System.out.println("cityList["+i+"]: "+
					cityList[i]);
		}
		
		System.out.println("****************2 D ARRAY*******************");
		int A[][]=new int[3][2];
		A[0][0]=9;
		A[0][1]=3;
		A[1][0]=7;
		A[1][1]=8;
		A[2][0]=4;
		A[2][1]=2;
		for(int i=0;i<A.length;i++)
		{
			for(int j=0;j<A[i].length;j++)
			{
				System.out.print("  "+A[i][j]);
			}
			System.out.println();
		}
	}
}