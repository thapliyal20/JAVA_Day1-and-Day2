
public class TestDateDemo1 {

	public static void main(String[] args) {
		
		Date kritikaDOJ=new Date(25,10,2017);
		System.out.println(" My DOJ is : " +kritikaDOJ.disDate());
		

		Date dhritiDOJ=new Date(26,10,2017);
		System.out.println(" My DOJ is : " +dhritiDOJ.disDate());
		

	}

}
