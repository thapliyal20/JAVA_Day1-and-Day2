class Factorial
{
	int num;
	public int calFact(int number)
	{
		num=number;
		int fact=1;
		while(num>1)
		{
			fact=fact*num--;
		}
		return fact;
			
	}
}

public class TestFactorialDemo 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int num=Integer.parseInt(args[0]);
		Factorial obj1=new Factorial();
		System.out.println("Factorial Of Number is : "+obj1.calFact(5));
	}

}
