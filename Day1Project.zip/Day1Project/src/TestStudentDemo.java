
public class TestStudentDemo 
{

	public static void main(String[] args)
	{
		Student s1=new Student();
		s1.setRollNo(240400);
		s1.setStuName("Kritika");
		s1.setMarks(85);
		
		Student s2=new Student();
		s2.setRollNo(260400);
		s2.setStuName("Danish");
		s2.setMarks(82);
		
		System.out.println(" Roll No : "+s1.getRollNo()+ 
				" Student Name : "+s1.getStuName()+ 
				" You got : "+s1.getMarks());
		

		System.out.println(" Roll No : "+s2.getRollNo()+ 
				" Student Name : "+s2.getStuName()+ 
				" You got : "+s2.getMarks());
		
	}

}
