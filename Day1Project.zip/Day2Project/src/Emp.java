
public class Emp
{
	static
	{
		System.out.println("static block is invoked when the classes are loaded "
	}
	private int empId;
	private String empName;
	private float empSal;
	private static int count;
	
	
	public Emp()
	{ }
	public Emp(int empId, String empName, float empSal)
	{
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		count++;
		
	}
	
	public static void getCount()
	{
		System.out.println(" Emp Count is :"+count);
	}
	
	public String dispInfo()
	{
		return "Emp [empId=" + empId + ", empName=" + empName +
				", Basic Emp Sal="
				+ empSal + "]";
	}
	public float calcEmpAnnualSal()
	{
		return empSal*12;
	}
}