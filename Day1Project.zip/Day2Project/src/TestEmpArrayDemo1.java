import java.util.*;
public class TestEmpArrayDemo1 
{
	public static void emp1(){
		System.out.println("non static ");
	}
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		Emp emps[] = new Emp[10];
		TestEmpArrayDemo1 tt=new TestEmpArrayDemo1();
		tt.emp1();
		System.out.println("Enter the number of Employees : ");
		int num= sc.nextInt();
		for(int i=0;i<num;i++)
		{
			System.out.println("Enter the Employee Id : ");
			int eid = sc.nextInt();
			
			System.out.println("Enter the Employee Name : ");
			String empname = sc.next();
			
			System.out.println("Enter the Employee Salary : ");
			float empsal = sc.nextFloat();
			
			emps[i]= new Emp(eid, empname, empsal);
			
		}
		for(int i=0;i<num;i++)
		{
			System.out.println("Emp Info: "+emps[i].dispInfo());
			System.out.println("emp annual salary: "+emps[i].calcEmpAnnualSal());
		}
		Emp.getCount();
		sc.close();
	}

}
