import java.util.Scanner;

public class TestPersonClass
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of Persons :");
		int numOfPerson=sc.nextInt();
		Person person[]=new Person[numOfPerson];
		
		for(int i=0;i<numOfPerson;i++)
		{
			System.out.println("Enter dd mm yyyy");
			int day=sc.nextInt();
			int month=sc.nextInt();
			int year=sc.nextInt();
			
			Date vDOB=new Date(day,month,year);
			System.out.println("PanNo perName and perSal");
			String panNo=sc.next();
			String perName=sc.next();
			float perSal=sc.nextFloat();
			person[i]=new Person(panNo,perName,perSal,vDOB);
		
		}
		
		
		for(int i=0;i<numOfPerson;i++){
			System.out.println(" "+person[i].dispPersonInfo());
		}
	}
}
