
public class TestPersonDemo1 {

	public static void main(String[] args)
	{
		Date vDOB=new Date(12,01,1990);
		Date aDOB=new Date(10,8,1994);
		Date pDOB=new Date(14,9,1997);
		
		Person veena=new Person("CBF5645","Veena K",40000.0F,vDOB);
		Person veena=new Person("CBF5645","Veena K",40000.0F,vDOB);
		
		System.out.println(" "+veena.dispPersonInfo());
		System.out.println(" "+veena.dispPersonInfo());
		
		Person veena=new Person("CBF5645","Veena K",40000.0F,Gender F,vDOB);
		System.out.println(" "+veena.dispPersonInfo());
		
	}

}
